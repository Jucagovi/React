const types = {
  multiplicar: "multiplicar",
  dividir: "dividir",
  reiniciar: "reiniciar",
  aumentar: "aumentar",
  disminuir: "disminuir",
  reiniciar: "reiniciar",
};

export default types;

import React from "react";
import "./Pie.css";

function Pie(props) {
  return <footer>{props.children}</footer>;
}

export default Pie;

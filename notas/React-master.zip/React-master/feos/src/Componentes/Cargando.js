import React from "react";

// const Cargando = (props) =>{
function Cargando(props) {
  return <h1>{props.texto}</h1>;
}
export default Cargando;

import React from "react";
import { Col, Container, Row } from "react-bootstrap";

const HomePagina = () => {
  return (
    <React.Fragment>
      <Container>
        <Row>
          <Col>
            <h2>Página inicial</h2>
          </Col>
        </Row>
      </Container>
    </React.Fragment>
  );
};

export default HomePagina;

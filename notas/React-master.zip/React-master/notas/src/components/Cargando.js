import React from "react";
import "./Cargando.css";

const Cargando = () => {
  return (
    <div className="lds-ripple">
      <div></div>
      <div></div>
    </div>
  );
};

export default Cargando;

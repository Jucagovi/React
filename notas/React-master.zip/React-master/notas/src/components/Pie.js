import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Pie = () => {
  return (
    <div>
      <React.Fragment>
        <Container>
          <Row>
            <Col className="text-right">Pie de página</Col>
          </Row>
        </Container>
      </React.Fragment>
    </div>
  );
};

export default Pie;

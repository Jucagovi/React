/***********************************************
 *** Estados iniciales
 ************************************************/

const idModuloInicial = "";
const moduloInicial = {
  nombre: "",
  abreviatura: "",
  curso: "",
  discentes: [{}],
  practicas: [{}],
};

const idDiscenteInicial = "";
const discenteInicial = "";
const practicaInicial = "";

/***********************************************
 *** Función reducer
 ************************************************/

const notasReducer = (state, action) => {
  switch (action) {
    default:
      return state;
  }
};

export { idModuloInicial, moduloInicial, idDiscenteInicial };
export default notasReducer;
